Project Name: Getting To Know Eachother
Author: Grant Gallagher
Email: granttgallagher@lewisu.edu
The project is to demonstrate basic knowlege of html and css
I referenced work from GitHub but wasn't sure if I have to list it being it isn't directly stolen.